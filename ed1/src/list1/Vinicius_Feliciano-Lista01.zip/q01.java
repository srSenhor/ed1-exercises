package list1;

public class q01 
{
	private static int my_age = 19;
	private static float my_height = 1.68f;
	private static char first_char = 'V';
	private static String my_name = "Vinicius Feliciano Alves do Nascimento";
	
	public static void main(String args[])
	{
		System.out.println("Nome completo: " + my_name);
		System.out.println("Primeira letra do nome: " + first_char);
		System.out.println("Idade: " + my_age);
		System.out.println("Altura: " + my_height);
	}
	
}
