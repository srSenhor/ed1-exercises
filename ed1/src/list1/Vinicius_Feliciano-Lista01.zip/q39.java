package list1;

public class q39 {
	//Criar CRUD de pessoa
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static <T>  (){
		return;
	}

}
