package list1;

public class q40 {

}
